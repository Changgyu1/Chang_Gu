package gaeul.review;

public class event_DTO {

	private int event_number;
	private int  event_name;
	private int  event_day;
	private int  event_time;
	private int  event_location;
	private int event_price;
	private int  event_age;
	private int  event_img;
	private int  event_explain;
	public int getEvent_number() {
		return event_number;
	}
	public void setEvent_number(int event_number) {
		this.event_number = event_number;
	}
	public int getEvent_name() {
		return event_name;
	}
	public void setEvent_name(int event_name) {
		this.event_name = event_name;
	}
	public int getEvent_day() {
		return event_day;
	}
	public void setEvent_day(int event_day) {
		this.event_day = event_day;
	}
	public int getEvent_time() {
		return event_time;
	}
	public void setEvent_time(int event_time) {
		this.event_time = event_time;
	}
	public int getEvent_location() {
		return event_location;
	}
	public void setEvent_location(int event_location) {
		this.event_location = event_location;
	}
	public int getEvent_price() {
		return event_price;
	}
	public void setEvent_price(int event_price) {
		this.event_price = event_price;
	}
	public int getEvent_age() {
		return event_age;
	}
	public void setEvent_age(int event_age) {
		this.event_age = event_age;
	}
	public int getEvent_img() {
		return event_img;
	}
	public void setEvent_img(int event_img) {
		this.event_img = event_img;
	}
	public int getEvent_explain() {
		return event_explain;
	}
	public void setEvent_explain(int event_explain) {
		this.event_explain = event_explain;
	}
	
}
